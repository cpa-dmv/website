(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,84026,e=>{"use strict";let t=(0,e.i(56420).default)("shield-check",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);e.s(["ShieldCheck",0,t],84026)},65649,e=>{"use strict";let t=(0,e.i(56420).default)("user-round",[["circle",{cx:"12",cy:"8",r:"5",key:"1hypcn"}],["path",{d:"M20 21a8 8 0 0 0-16 0",key:"rfgkzh"}]]);e.s(["UserRound",0,t],65649)},89664,e=>{"use strict";let t=(0,e.i(56420).default)("check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);e.s(["Check",0,t],89664)},67784,e=>{"use strict";let t=(0,e.i(56420).default)("log-out",[["path",{d:"m16 17 5-5-5-5",key:"1bji2h"}],["path",{d:"M21 12H9",key:"dn1m92"}],["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}]]);e.s(["LogOut",0,t],67784)},16015,(e,t,s)=>{},98547,(e,t,s)=>{var a=e.i(47167);e.r(16015);var i=e.r(71645),r=i&&"object"==typeof i&&"default"in i?i:{default:i},n=void 0!==a.default&&a.default.env&&!0,o=function(e){return"[object String]"===Object.prototype.toString.call(e)},l=function(){function e(e){var t=void 0===e?{}:e,s=t.name,a=void 0===s?"stylesheet":s,i=t.optimizeForSpeed,r=void 0===i?n:i;c(o(a),"`name` must be a string"),this._name=a,this._deletedRulePlaceholder="#"+a+"-deleted-rule____{}",c("boolean"==typeof r,"`optimizeForSpeed` must be a boolean"),this._optimizeForSpeed=r,this._serverSheet=void 0,this._tags=[],this._injected=!1,this._rulesCount=0;var l="u">typeof window&&document.querySelector('meta[property="csp-nonce"]');this._nonce=l?l.getAttribute("content"):null}var t,s=e.prototype;return s.setOptimizeForSpeed=function(e){c("boolean"==typeof e,"`setOptimizeForSpeed` accepts a boolean"),c(0===this._rulesCount,"optimizeForSpeed cannot be when rules have already been inserted"),this.flush(),this._optimizeForSpeed=e,this.inject()},s.isOptimizeForSpeed=function(){return this._optimizeForSpeed},s.inject=function(){var e=this;if(c(!this._injected,"sheet already injected"),this._injected=!0,"u">typeof window&&this._optimizeForSpeed){this._tags[0]=this.makeStyleTag(this._name),this._optimizeForSpeed="insertRule"in this.getSheet(),this._optimizeForSpeed||(n||console.warn("StyleSheet: optimizeForSpeed mode not supported falling back to standard mode."),this.flush(),this._injected=!0);return}this._serverSheet={cssRules:[],insertRule:function(t,s){return"number"==typeof s?e._serverSheet.cssRules[s]={cssText:t}:e._serverSheet.cssRules.push({cssText:t}),s},deleteRule:function(t){e._serverSheet.cssRules[t]=null}}},s.getSheetForTag=function(e){if(e.sheet)return e.sheet;for(var t=0;t<document.styleSheets.length;t++)if(document.styleSheets[t].ownerNode===e)return document.styleSheets[t]},s.getSheet=function(){return this.getSheetForTag(this._tags[this._tags.length-1])},s.insertRule=function(e,t){if(c(o(e),"`insertRule` accepts only strings"),"u"<typeof window)return"number"!=typeof t&&(t=this._serverSheet.cssRules.length),this._serverSheet.insertRule(e,t),this._rulesCount++;if(this._optimizeForSpeed){var s=this.getSheet();"number"!=typeof t&&(t=s.cssRules.length);try{s.insertRule(e,t)}catch(t){return n||console.warn("StyleSheet: illegal rule: \n\n"+e+"\n\nSee https://stackoverflow.com/q/20007992 for more info"),-1}}else{var a=this._tags[t];this._tags.push(this.makeStyleTag(this._name,e,a))}return this._rulesCount++},s.replaceRule=function(e,t){if(this._optimizeForSpeed||"u"<typeof window){var s="u">typeof window?this.getSheet():this._serverSheet;if(t.trim()||(t=this._deletedRulePlaceholder),!s.cssRules[e])return e;s.deleteRule(e);try{s.insertRule(t,e)}catch(a){n||console.warn("StyleSheet: illegal rule: \n\n"+t+"\n\nSee https://stackoverflow.com/q/20007992 for more info"),s.insertRule(this._deletedRulePlaceholder,e)}}else{var a=this._tags[e];c(a,"old rule at index `"+e+"` not found"),a.textContent=t}return e},s.deleteRule=function(e){if("u"<typeof window)return void this._serverSheet.deleteRule(e);if(this._optimizeForSpeed)this.replaceRule(e,"");else{var t=this._tags[e];c(t,"rule at index `"+e+"` not found"),t.parentNode.removeChild(t),this._tags[e]=null}},s.flush=function(){this._injected=!1,this._rulesCount=0,"u">typeof window?(this._tags.forEach(function(e){return e&&e.parentNode.removeChild(e)}),this._tags=[]):this._serverSheet.cssRules=[]},s.cssRules=function(){var e=this;return"u"<typeof window?this._serverSheet.cssRules:this._tags.reduce(function(t,s){return s?t=t.concat(Array.prototype.map.call(e.getSheetForTag(s).cssRules,function(t){return t.cssText===e._deletedRulePlaceholder?null:t})):t.push(null),t},[])},s.makeStyleTag=function(e,t,s){t&&c(o(t),"makeStyleTag accepts only strings as second parameter");var a=document.createElement("style");this._nonce&&a.setAttribute("nonce",this._nonce),a.type="text/css",a.setAttribute("data-"+e,""),t&&a.appendChild(document.createTextNode(t));var i=document.head||document.getElementsByTagName("head")[0];return s?i.insertBefore(a,s):i.appendChild(a),a},t=[{key:"length",get:function(){return this._rulesCount}}],function(e,t){for(var s=0;s<t.length;s++){var a=t[s];a.enumerable=a.enumerable||!1,a.configurable=!0,"value"in a&&(a.writable=!0),Object.defineProperty(e,a.key,a)}}(e.prototype,t),e}();function c(e,t){if(!e)throw Error("StyleSheet: "+t+".")}var h=function(e){for(var t=5381,s=e.length;s;)t=33*t^e.charCodeAt(--s);return t>>>0},d={};function p(e,t){if(!t)return"jsx-"+e;var s=String(t),a=e+s;return d[a]||(d[a]="jsx-"+h(e+"-"+s)),d[a]}function u(e,t){"u"<typeof window&&(t=t.replace(/\/style/gi,"\\/style"));var s=e+t;return d[s]||(d[s]=t.replace(/__jsx-style-dynamic-selector/g,e)),d[s]}var x=function(){function e(e){var t=void 0===e?{}:e,s=t.styleSheet,a=void 0===s?null:s,i=t.optimizeForSpeed,r=void 0!==i&&i;this._sheet=a||new l({name:"styled-jsx",optimizeForSpeed:r}),this._sheet.inject(),a&&"boolean"==typeof r&&(this._sheet.setOptimizeForSpeed(r),this._optimizeForSpeed=this._sheet.isOptimizeForSpeed()),this._fromServer=void 0,this._indices={},this._instancesCounts={}}var t=e.prototype;return t.add=function(e){var t=this;void 0===this._optimizeForSpeed&&(this._optimizeForSpeed=Array.isArray(e.children),this._sheet.setOptimizeForSpeed(this._optimizeForSpeed),this._optimizeForSpeed=this._sheet.isOptimizeForSpeed()),"u">typeof window&&!this._fromServer&&(this._fromServer=this.selectFromServer(),this._instancesCounts=Object.keys(this._fromServer).reduce(function(e,t){return e[t]=0,e},{}));var s=this.getIdAndRules(e),a=s.styleId,i=s.rules;if(a in this._instancesCounts){this._instancesCounts[a]+=1;return}var r=i.map(function(e){return t._sheet.insertRule(e)}).filter(function(e){return -1!==e});this._indices[a]=r,this._instancesCounts[a]=1},t.remove=function(e){var t=this,s=this.getIdAndRules(e).styleId;if(function(e,t){if(!e)throw Error("StyleSheetRegistry: "+t+".")}(s in this._instancesCounts,"styleId: `"+s+"` not found"),this._instancesCounts[s]-=1,this._instancesCounts[s]<1){var a=this._fromServer&&this._fromServer[s];a?(a.parentNode.removeChild(a),delete this._fromServer[s]):(this._indices[s].forEach(function(e){return t._sheet.deleteRule(e)}),delete this._indices[s]),delete this._instancesCounts[s]}},t.update=function(e,t){this.add(t),this.remove(e)},t.flush=function(){this._sheet.flush(),this._sheet.inject(),this._fromServer=void 0,this._indices={},this._instancesCounts={}},t.cssRules=function(){var e=this,t=this._fromServer?Object.keys(this._fromServer).map(function(t){return[t,e._fromServer[t]]}):[],s=this._sheet.cssRules();return t.concat(Object.keys(this._indices).map(function(t){return[t,e._indices[t].map(function(e){return s[e].cssText}).join(e._optimizeForSpeed?"":"\n")]}).filter(function(e){return!!e[1]}))},t.styles=function(e){var t,s;return t=this.cssRules(),void 0===(s=e)&&(s={}),t.map(function(e){var t=e[0],a=e[1];return r.default.createElement("style",{id:"__"+t,key:"__"+t,nonce:s.nonce?s.nonce:void 0,dangerouslySetInnerHTML:{__html:a}})})},t.getIdAndRules=function(e){var t=e.children,s=e.dynamic,a=e.id;if(s){var i=p(a,s);return{styleId:i,rules:Array.isArray(t)?t.map(function(e){return u(i,e)}):[u(i,t)]}}return{styleId:p(a),rules:Array.isArray(t)?t:[t]}},t.selectFromServer=function(){return Array.prototype.slice.call(document.querySelectorAll('[id^="__jsx-"]')).reduce(function(e,t){return e[t.id.slice(2)]=t,e},{})},e}(),m=i.createContext(null);function f(){return new x}function g(){return i.useContext(m)}m.displayName="StyleSheetContext";var _=r.default.useInsertionEffect||r.default.useLayoutEffect,y="u">typeof window?f():void 0;function j(e){var t=y||g();return t&&("u"<typeof window?t.add(e):_(function(){return t.add(e),function(){t.remove(e)}},[e.id,String(e.dynamic)])),null}j.dynamic=function(e){return e.map(function(e){return p(e[0],e[1])}).join(" ")},s.StyleRegistry=function(e){var t=e.registry,s=e.children,a=i.useContext(m),n=i.useState(function(){return a||t||f()})[0];return r.default.createElement(m.Provider,{value:n},s)},s.createStyleRegistry=f,s.style=j,s.useStyleRegistry=g},37902,(e,t,s)=>{t.exports=e.r(98547).style},83155,e=>{"use strict";var t=e.i(43476),s=e.i(37902),a=e.i(71645),i=e.i(89664),r=e.i(56420);let n=(0,r.default)("check-check",[["path",{d:"M18 6 7 17l-5-5",key:"116fxf"}],["path",{d:"m22 10-7.5 7.5L13 16",key:"ke71qq"}]]);var o=e.i(58379),o=o;let l=(0,r.default)("lock-keyhole",[["circle",{cx:"12",cy:"16",r:"1",key:"1au0dj"}],["rect",{x:"3",y:"10",width:"18",height:"12",rx:"2",key:"6s8ecr"}],["path",{d:"M7 10V7a5 5 0 0 1 10 0v3",key:"1pqi11"}]]);var c=e.i(67784),h=e.i(15227),d=e.i(30274),p=e.i(84026),u=e.i(65649);async function x(e,t={}){let s=await fetch(`/api/chat/api/${e}`,{...t,credentials:"same-origin",headers:{Accept:"application/json",...t.body?{"Content-Type":"application/json"}:{},...t.headers},cache:"no-store"}),a=await s.json().catch(()=>({}));if(!s.ok||!1===a.success)throw Error(a.message||"Something went wrong. Please try again.");return a}let m=`
  .client-chat-shell {
    --navy: #102a25;
    --green: #174e3b;
    --gold: #d4ad58;
    --ink: #172b25;
    --muted: #718079;
    min-height: 100vh;
    padding: 0 6%;
    color: var(--ink);
    background: #f6f8f6;
    font-family: Arial, Helvetica, sans-serif;
  }
  .chat-topbar {
    height: 86px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #e3e9e4;
  }
  .brand {
    display: flex;
    align-items: center;
    gap: 12px;
    color: var(--navy);
    text-decoration: none;
  }
  .brand-mark {
    width: 43px;
    height: 43px;
    display: grid;
    place-items: center;
    border-radius: 12px;
    background: var(--green);
    color: white;
    font-family: Georgia, serif;
    font-size: 26px;
    font-weight: bold;
  }
  .brand strong, .brand small { display: block; }
  .brand strong { font-size: 19px; letter-spacing: .2px; }
  .brand small { margin-top: 4px; font-size: 9px; letter-spacing: 2px; color: #7b8b81; }
  .logout-button {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    border: 1px solid #dce5de;
    border-radius: 9px;
    padding: 10px 14px;
    background: white;
    color: #40564a;
    cursor: pointer;
    font-size: 13px;
  }
  .auth-layout {
    max-width: 1110px;
    min-height: calc(100vh - 160px);
    margin: auto;
    padding: 64px 0;
    display: grid;
    grid-template-columns: 1.05fr .8fr;
    align-items: center;
    gap: 90px;
  }
  .eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    color: var(--green);
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 1.8px;
  }
  .auth-intro h1 {
    margin: 22px 0;
    font-family: Georgia, 'Times New Roman', serif;
    font-size: clamp(38px, 4.5vw, 60px);
    line-height: 1.12;
    letter-spacing: -1.6px;
    font-weight: 500;
  }
  .auth-intro h1 span { color: var(--green); font-style: italic; }
  .auth-intro > p {
    max-width: 440px;
    color: #68766e;
    font-size: 16px;
    line-height: 1.9;
  }
  .trust-row {
    margin-top: 32px;
    display: flex;
    align-items: center;
    gap: 11px;
    color: #52685b;
    font-size: 13px;
  }
  .auth-card {
    border: 1px solid #e4e9e4;
    border-radius: 19px;
    background: white;
    padding: 32px;
    box-shadow: 0 20px 65px rgba(27, 55, 40, .06);
  }
  .auth-icon {
    width: 48px;
    height: 48px;
    display: grid;
    place-items: center;
    border-radius: 14px;
    background: #eaf2ec;
    color: var(--green);
  }
  .auth-card h2 { margin: 22px 0 8px; font-size: 25px; letter-spacing: -.5px; }
  .auth-subtitle { margin: 0; color: #7a867f; font-size: 13px; line-height: 1.6; }
  .mode-switch {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 4px;
    margin: 24px 0;
    padding: 4px;
    background: #f3f6f3;
    border-radius: 10px;
  }
  .mode-switch button {
    border: 0;
    border-radius: 7px;
    padding: 11px 5px;
    background: transparent;
    color: #728077;
    font-size: 12px;
    cursor: pointer;
  }
  .mode-switch button.active {
    color: var(--green);
    background: white;
    box-shadow: 0 1px 4px #dfe6df;
    font-weight: 700;
  }
  .auth-form { display: grid; gap: 17px; }
  .auth-form label { display: grid; gap: 8px; color: #405148; font-size: 12px; font-weight: 700; }
  .auth-form input {
    box-sizing: border-box;
    width: 100%;
    min-width: 0;
    padding: 13px 14px;
    border: 1px solid #dfe6e0;
    border-radius: 9px;
    outline: none;
    background: white;
    color: #1b3026;
    font: inherit;
    font-weight: 400;
    font-size: 13px;
  }
  .auth-form input:focus, .composer textarea:focus { border-color: #6b9b7c; box-shadow: 0 0 0 3px #e7f1e9; }
  .field-wrap { position: relative; display: flex; align-items: center; }
  .field-wrap > svg { position: absolute; left: 13px; color: #839187; }
  .field-wrap input { padding-left: 40px; }
  .primary-button {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    width: 100%;
    min-height: 47px;
    margin-top: 2px;
    border: 0;
    border-radius: 9px;
    background: var(--green);
    color: white;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
  }
  .primary-button:disabled, .send-button:disabled { opacity: .6; cursor: not-allowed; }
  .privacy-note {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 6px;
    margin: 22px 0 0;
    color: #859188;
    font-size: 10px;
  }
  .alert { margin: 0; padding: 10px 12px; border-radius: 8px; font-size: 12px; line-height: 1.5; }
  .error-alert { background: #fff0ee; color: #a5372a; }
  .success-alert { background: #edf7ef; color: #286341; }
  .chat-layout { max-width: 950px; margin: auto; padding: 42px 0 32px; }
  .chat-heading { display: flex; align-items: center; gap: 14px; margin-bottom: 25px; }
  .chat-heading-icon { display: grid; place-items: center; width: 50px; height: 50px; border-radius: 13px; background: #e5efe7; color: var(--green); }
  .chat-heading h1 { margin: 0 0 5px; font-family: Georgia, serif; font-size: 29px; font-weight: 500; }
  .chat-heading p { margin: 0; color: #77857c; font-size: 13px; }
  .secure-label { display: flex; align-items: center; gap: 6px; margin-left: auto; padding: 8px 10px; border-radius: 20px; background: #eaf3eb; color: #2e6a45; font-size: 11px; white-space: nowrap; }
  .chat-panel { overflow: hidden; border: 1px solid #e0e7e0; border-radius: 15px; background: white; box-shadow: 0 14px 45px rgba(28, 58, 39, .05); }
  .conversation-header { display: flex; align-items: center; gap: 12px; padding: 19px 22px; border-bottom: 1px solid #edf0ed; }
  .support-avatar, .message-avatar { display: grid; place-items: center; flex: 0 0 auto; width: 42px; height: 42px; border-radius: 50%; background: var(--green); color: white; font-family: Georgia, serif; font-size: 20px; }
  .conversation-header strong, .conversation-header span { display: block; }
  .conversation-header strong { margin-bottom: 5px; font-size: 14px; }
  .conversation-header span { color: #7a887e; font-size: 11px; }
  .conversation-header .online-dot { display: inline-block; width: 7px; height: 7px; margin-right: 5px; border-radius: 50%; background: #52a76c; }
  .conversation-header .conversation-tag { margin-left: auto; padding: 7px 10px; border-radius: 6px; background: #f3f6f3; color: #68796d; white-space: nowrap; }
  .messages-area { min-height: 300px; max-height: 52vh; overflow-y: auto; padding: 22px; background: #fcfdfc; }
  .date-divider { display: flex; justify-content: center; margin-bottom: 22px; }
  .date-divider span { padding: 7px 11px; border: 1px solid #edf0ed; border-radius: 20px; background: white; color: #869188; font-size: 9px; letter-spacing: 1px; }
  .welcome-note { max-width: 390px; margin: 0 auto 28px; padding: 20px; border: 1px solid #e8eee8; border-radius: 12px; background: white; text-align: center; }
  .welcome-icon { display: grid; place-items: center; width: 40px; height: 40px; margin: 0 auto 12px; border-radius: 12px; background: #edf4ee; color: var(--green); }
  .welcome-note strong { font-size: 13px; }
  .welcome-note p { margin: 9px 0 0; color: #78847c; font-size: 12px; line-height: 1.7; }
  .message-row { display: flex; align-items: flex-end; gap: 9px; margin: 17px 0; }
  .message-row.mine { justify-content: flex-end; }
  .message-avatar { width: 29px; height: 29px; font-size: 14px; }
  .message-content { max-width: min(72%, 540px); display: flex; flex-direction: column; gap: 5px; }
  .mine .message-content { align-items: flex-end; }
  .message-sender { color: #7e8a81; font-size: 10px; }
  .message-bubble { padding: 12px 15px; border: 1px solid #e5eae5; border-radius: 13px 13px 13px 3px; background: white; color: #304137; font-size: 13px; line-height: 1.7; white-space: pre-wrap; overflow-wrap: anywhere; }
  .mine .message-bubble { border-color: var(--green); border-radius: 13px 13px 3px 13px; background: var(--green); color: white; }
  .message-meta { display: flex; align-items: center; gap: 4px; color: #96a098; font-size: 10px; }
  .composer { position: relative; display: flex; align-items: flex-end; gap: 12px; padding: 18px 20px 36px; border-top: 1px solid #e9eee9; background: white; }
  .composer textarea { box-sizing: border-box; flex: 1; min-width: 0; resize: vertical; min-height: 49px; max-height: 150px; padding: 14px; border: 1px solid #dfe7df; border-radius: 10px; outline: none; color: #25392d; font: inherit; font-size: 13px; line-height: 1.5; }
  .send-button { display: flex; align-items: center; justify-content: center; gap: 8px; min-width: 95px; height: 47px; border: 0; border-radius: 9px; background: var(--green); color: white; font-size: 12px; font-weight: 700; cursor: pointer; }
  .composer-hint { position: absolute; left: 22px; bottom: 12px; color: #97a199; font-size: 10px; }
  .chat-error { margin: 0; padding: 10px 20px; background: #fff1ef; color: #a5372a; font-size: 12px; }
  .chat-footer-note { display: flex; align-items: center; justify-content: center; gap: 7px; margin-top: 18px; color: #859188; font-size: 11px; line-height: 1.6; text-align: center; }
  .page-footer { min-height: 70px; display: flex; align-items: center; justify-content: space-between; gap: 15px; border-top: 1px solid #e2e9e2; color: #849087; font-size: 11px; }
  .page-footer a { color: #42664f; text-decoration: none; }
  .client-chat-loading { min-height: 75vh; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 14px; color: var(--green); }
  .client-chat-loading p { font-size: 13px; }
  .animate-spin { animation: spin 1s linear infinite; }
  @keyframes spin { to { transform: rotate(360deg); } }
  @media (max-width: 800px) {
    .client-chat-shell { padding: 0 5%; }
    .auth-layout { grid-template-columns: 1fr; gap: 30px; padding: 40px 0; }
    .auth-intro h1 { font-size: 43px; }
    .auth-card { padding: 25px; }
    .chat-layout { padding-top: 28px; }
    .chat-heading h1 { font-size: 25px; }
    .secure-label { display: none; }
    .messages-area { max-height: 55vh; padding: 16px 12px; }
    .conversation-header { padding: 15px 13px; }
    .conversation-header .conversation-tag { display: none; }
    .composer { padding: 13px 12px 37px; gap: 8px; }
    .send-button { min-width: 48px; width: 48px; }
    .send-button span { display: none; }
    .message-content { max-width: 83%; }
    .page-footer { flex-wrap: wrap; padding: 18px 0; }
  }
  @media (prefers-reduced-motion: reduce) {
    .animate-spin { animation: none; }
  }
`;e.s(["default",0,function(){let[e,r]=(0,a.useState)("register"),[f,g]=(0,a.useState)(null),[_,y]=(0,a.useState)(""),[j,b]=(0,a.useState)([]),[v,w]=(0,a.useState)(null),[S,N]=(0,a.useState)(""),[k,z]=(0,a.useState)(""),[$,C]=(0,a.useState)(""),[R,T]=(0,a.useState)(""),[F,P]=(0,a.useState)(!0),[A,E]=(0,a.useState)(!1),[O,I]=(0,a.useState)(""),[M,V]=(0,a.useState)(""),D=(0,a.useRef)(null),L=(0,a.useRef)(null),q=(0,a.useCallback)(async()=>{try{let e=await x("messages.php?action=list");e.messages&&b(e.messages),"number"==typeof e.conversation?.id?w(e.conversation.id):"number"==typeof e.conversation_id&&w(e.conversation_id)}catch(e){e instanceof Error&&I(e.message)}},[]),Y=(0,a.useCallback)(async()=>{P(!0);try{let e=await x("auth.php?action=me");y(e.csrfToken||e.csrf_token||"");let t=e.user||e.client||null;g(e.authenticated?t:null)}catch{g(null)}finally{P(!1)}},[]);async function U(t){t.preventDefault(),I(""),V(""),E(!0);try{let t=_;if(!t){let e=await x("auth.php?action=csrf");t=e.csrfToken||e.csrf_token||"",y(t)}if(!t)throw Error("Could not establish a secure session. Please refresh and try again.");let s={name:S.trim(),email:k.trim()};"register"===e&&(s.phone=$.trim());let a=await x(`auth.php?action=${e}`,{method:"POST",headers:{"X-CSRF-Token":t},body:JSON.stringify(s)}),i=a.user||a.client;if(!i)throw Error(a.message||"Authentication response was incomplete.");g(i),y(a.csrfToken||a.csrf_token||t),C(""),V("register"===e?"Your account has been created. You can now chat with our team.":"Welcome back. Your private conversation is ready.")}catch(e){I(e instanceof Error?e.message:"Unable to authenticate.")}finally{E(!1)}}async function B(e){e.preventDefault();let t=R.trim();if(t&&!A){I(""),E(!0);try{if(!_)throw Error("Your session has expired. Please sign in again.");await x("messages.php?action=send",{method:"POST",headers:{"X-CSRF-Token":_},body:JSON.stringify({message:t,conversation_id:v,csrf_token:_})}),T(""),await q(),L.current?.focus()}catch(e){I(e instanceof Error?e.message:"Unable to send message.")}finally{E(!1)}}}async function H(){I("");try{await x("auth.php?action=logout",{method:"POST",headers:_?{"X-CSRF-Token":_}:{},body:JSON.stringify({action:"logout",csrf_token:_})})}catch{}g(null),b([]),w(null),y(""),V(""),r("login")}return((0,a.useEffect)(()=>{Y()},[Y]),(0,a.useEffect)(()=>{if(!f)return;q();let e=window.setInterval(()=>void q(),3e3);return()=>window.clearInterval(e)},[f,q]),(0,a.useEffect)(()=>{D.current?.scrollIntoView({behavior:"smooth",block:"end"})},[j]),F)?(0,t.jsxs)("main",{className:`jsx-${m.__hash} client-chat-shell`,children:[(0,t.jsxs)("div",{className:`jsx-${m.__hash} client-chat-loading`,children:[(0,t.jsx)(o.default,{className:"animate-spin",size:28}),(0,t.jsx)("p",{className:`jsx-${m.__hash}`,children:"Connecting to CPA-DMV Support…"})]}),(0,t.jsx)(s.default,{id:m.__hash,children:m})]}):(0,t.jsxs)("main",{className:`jsx-${m.__hash} client-chat-shell`,children:[(0,t.jsxs)("header",{className:`jsx-${m.__hash} chat-topbar`,children:[(0,t.jsxs)("a",{href:"/","aria-label":"CPA-DMV home",className:`jsx-${m.__hash} brand`,children:[(0,t.jsx)("span",{className:`jsx-${m.__hash} brand-mark`,children:"C"}),(0,t.jsxs)("span",{className:`jsx-${m.__hash}`,children:[(0,t.jsx)("strong",{className:`jsx-${m.__hash}`,children:"CPA-DMV"}),(0,t.jsx)("small",{className:`jsx-${m.__hash}`,children:"CLIENT SUPPORT"})]})]}),f&&(0,t.jsxs)("button",{onClick:H,type:"button",className:`jsx-${m.__hash} logout-button`,children:[(0,t.jsx)(c.LogOut,{size:16}),(0,t.jsx)("span",{className:`jsx-${m.__hash}`,children:"Sign out"})]})]}),f?(0,t.jsxs)("section",{className:`jsx-${m.__hash} chat-layout`,children:[(0,t.jsxs)("div",{className:`jsx-${m.__hash} chat-heading`,children:[(0,t.jsx)("div",{className:`jsx-${m.__hash} chat-heading-icon`,children:(0,t.jsx)(h.MessageCircle,{size:24})}),(0,t.jsxs)("div",{className:`jsx-${m.__hash}`,children:[(0,t.jsx)("h1",{className:`jsx-${m.__hash}`,children:"Client support"}),(0,t.jsxs)("p",{className:`jsx-${m.__hash}`,children:["Hello, ",f.name,". Send a message to speak with our team."]})]}),(0,t.jsxs)("span",{className:`jsx-${m.__hash} secure-label`,children:[(0,t.jsx)(l,{size:13})," Private chat"]})]}),(0,t.jsxs)("div",{className:`jsx-${m.__hash} chat-panel`,children:[(0,t.jsxs)("div",{className:`jsx-${m.__hash} conversation-header`,children:[(0,t.jsx)("div",{className:`jsx-${m.__hash} support-avatar`,children:"C"}),(0,t.jsxs)("div",{className:`jsx-${m.__hash}`,children:[(0,t.jsx)("strong",{className:`jsx-${m.__hash}`,children:"CPA-DMV Support"}),(0,t.jsxs)("span",{className:`jsx-${m.__hash}`,children:[(0,t.jsx)("i",{className:`jsx-${m.__hash} online-dot`})," Client services team"]})]}),(0,t.jsx)("span",{className:`jsx-${m.__hash} conversation-tag`,children:"1:1 Conversation"})]}),(0,t.jsxs)("div",{className:`jsx-${m.__hash} messages-area`,children:[(0,t.jsx)("div",{className:`jsx-${m.__hash} date-divider`,children:(0,t.jsx)("span",{className:`jsx-${m.__hash}`,children:"YOUR PRIVATE CONVERSATION"})}),(0,t.jsxs)("div",{className:`jsx-${m.__hash} welcome-note`,children:[(0,t.jsx)("div",{className:`jsx-${m.__hash} welcome-icon`,children:(0,t.jsx)(p.ShieldCheck,{size:21})}),(0,t.jsx)("strong",{className:`jsx-${m.__hash}`,children:"Welcome to CPA-DMV Support"}),(0,t.jsx)("p",{className:`jsx-${m.__hash}`,children:"Send us your question and a member of our team will respond here. You can return anytime to view the conversation."})]}),j.map(e=>{let s,a="client"===e.sender_type;return(0,t.jsxs)("div",{className:`jsx-${m.__hash} message-row ${a?"mine":"theirs"}`,children:[!a&&(0,t.jsx)("div",{className:`jsx-${m.__hash} message-avatar`,children:"C"}),(0,t.jsxs)("div",{className:`jsx-${m.__hash} message-content`,children:[(0,t.jsx)("span",{className:`jsx-${m.__hash} message-sender`,children:a?"You":"CPA-DMV Support"}),(0,t.jsx)("div",{className:`jsx-${m.__hash} message-bubble`,children:e.message}),(0,t.jsxs)("span",{className:`jsx-${m.__hash} message-meta`,children:[Number.isNaN((s=new Date(e.created_at.replace(" ","T"))).getTime())?"":s.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}),a&&(e.read_at?(0,t.jsx)(n,{size:14}):(0,t.jsx)(i.Check,{size:14}))]})]})]},e.id)}),(0,t.jsx)("div",{ref:D,className:`jsx-${m.__hash}`})]}),O&&(0,t.jsx)("p",{className:`jsx-${m.__hash} chat-error`,children:O}),(0,t.jsxs)("form",{onSubmit:B,className:`jsx-${m.__hash} composer`,children:[(0,t.jsx)("textarea",{ref:L,value:R,onChange:e=>T(e.target.value),placeholder:"Write your message…",rows:2,maxLength:5e3,"aria-label":"Write your message",onKeyDown:e=>{"Enter"!==e.key||e.shiftKey||(e.preventDefault(),e.currentTarget.form?.requestSubmit())},className:`jsx-${m.__hash}`}),(0,t.jsx)("button",{type:"submit",disabled:A||!R.trim(),"aria-label":"Send message",className:`jsx-${m.__hash} send-button`,children:A?(0,t.jsx)(o.default,{size:19,className:"animate-spin"}):(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(d.Send,{size:17}),(0,t.jsx)("span",{className:`jsx-${m.__hash}`,children:"Send"})]})}),(0,t.jsx)("span",{className:`jsx-${m.__hash} composer-hint`,children:"Press Enter to send · Shift + Enter for a new line"})]})]}),(0,t.jsxs)("div",{className:`jsx-${m.__hash} chat-footer-note`,children:[(0,t.jsx)(l,{size:14}),"Please avoid sending passwords, payment card details, or other highly sensitive information in chat."]})]}):(0,t.jsxs)("section",{className:`jsx-${m.__hash} auth-layout`,children:[(0,t.jsxs)("div",{className:`jsx-${m.__hash} auth-intro`,children:[(0,t.jsxs)("span",{className:`jsx-${m.__hash} eyebrow`,children:[(0,t.jsx)(p.ShieldCheck,{size:15})," PRIVATE CLIENT PORTAL"]}),(0,t.jsxs)("h1",{className:`jsx-${m.__hash}`,children:["Your questions.",(0,t.jsx)("br",{className:`jsx-${m.__hash}`}),"Our ",(0,t.jsx)("span",{className:`jsx-${m.__hash}`,children:"personal attention."})]}),(0,t.jsx)("p",{className:`jsx-${m.__hash}`,children:"Connect directly with the CPA-DMV team through your own private conversation. Sign in anytime to continue where you left off."}),(0,t.jsxs)("div",{className:`jsx-${m.__hash} trust-row`,children:[(0,t.jsx)(l,{size:18}),(0,t.jsx)("span",{className:`jsx-${m.__hash}`,children:"Private account · One-to-one support"})]})]}),(0,t.jsxs)("div",{className:`jsx-${m.__hash} auth-card`,children:[(0,t.jsx)("div",{className:`jsx-${m.__hash} auth-icon`,children:(0,t.jsx)(h.MessageCircle,{size:25})}),(0,t.jsx)("h2",{className:`jsx-${m.__hash}`,children:"register"===e?"Create your account":"Welcome back"}),(0,t.jsx)("p",{className:`jsx-${m.__hash} auth-subtitle`,children:"register"===e?"Register to start a conversation with our team.":"Sign in to access your private chat."}),(0,t.jsxs)("div",{className:`jsx-${m.__hash} mode-switch`,children:[(0,t.jsx)("button",{type:"button",onClick:()=>{r("register"),I("")},className:`jsx-${m.__hash} `+(("register"===e?"active":"")||""),children:"Create account"}),(0,t.jsx)("button",{type:"button",onClick:()=>{r("login"),I("")},className:`jsx-${m.__hash} `+(("login"===e?"active":"")||""),children:"Sign in"})]}),(0,t.jsxs)("form",{onSubmit:U,className:`jsx-${m.__hash} auth-form`,children:["register"===e&&(0,t.jsxs)("label",{className:`jsx-${m.__hash}`,children:["Full name",(0,t.jsxs)("span",{className:`jsx-${m.__hash} field-wrap`,children:[(0,t.jsx)(u.UserRound,{size:17}),(0,t.jsx)("input",{value:S,onChange:e=>N(e.target.value),placeholder:"Your full name",autoComplete:"name",maxLength:150,required:!0,className:`jsx-${m.__hash}`})]})]}),(0,t.jsxs)("label",{className:`jsx-${m.__hash}`,children:["Email address",(0,t.jsx)("input",{type:"email",value:k,onChange:e=>z(e.target.value),placeholder:"you@example.com",autoComplete:"email",maxLength:254,required:!0,className:`jsx-${m.__hash}`})]}),"register"===e&&(0,t.jsxs)("label",{className:`jsx-${m.__hash}`,children:["Phone number (optional)",(0,t.jsx)("input",{type:"tel",value:$,onChange:e=>C(e.target.value),placeholder:"Your phone number",autoComplete:"tel",maxLength:30,className:`jsx-${m.__hash}`})]}),O&&(0,t.jsx)("p",{className:`jsx-${m.__hash} alert error-alert`,children:O}),M&&(0,t.jsx)("p",{className:`jsx-${m.__hash} alert success-alert`,children:M}),(0,t.jsx)("button",{disabled:A,className:`jsx-${m.__hash} primary-button`,children:A?(0,t.jsx)(o.default,{size:18,className:"animate-spin"}):"register"===e?"Create account":"Sign in securely"})]}),(0,t.jsxs)("p",{className:`jsx-${m.__hash} privacy-note`,children:[(0,t.jsx)(l,{size:13}),"Your account and messages are private to your conversation."]})]})]}),(0,t.jsxs)("footer",{className:`jsx-${m.__hash} page-footer`,children:[(0,t.jsxs)("span",{className:`jsx-${m.__hash}`,children:["© ",new Date().getFullYear()," CPA-DMV"]}),(0,t.jsx)("span",{className:`jsx-${m.__hash}`,children:"Professional service. Personal attention."}),(0,t.jsx)("a",{href:"/",className:`jsx-${m.__hash}`,children:"Back to website"})]}),(0,t.jsx)(s.default,{id:m.__hash,children:m})]})}],83155)}]);